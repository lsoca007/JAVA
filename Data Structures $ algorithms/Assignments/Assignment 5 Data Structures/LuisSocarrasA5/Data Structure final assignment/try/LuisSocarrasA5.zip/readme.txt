	Source currency is USD
Kuwaiti Dinar: max Exchange Rate is 0.306859 and direct rate is 0.306859
Bahraini Dinar: max Exchange Rate is 0.376 and direct rate is 0.376
Omani Rial: max Exchange Rate is 0.3845 and direct rate is 0.3845
British Pound: max Exchange Rate is 0.785824 and direct rate is 0.785824
Euro: max Exchange Rate is 0.863744 and direct rate is 0.863744
Swiss Franc: max Exchange Rate is 0.92926 and direct rate is 0.92926
Canadian Dollar: max Exchange Rate is 1.340709 and direct rate is 1.340709
Bruneian Dollar: max Exchange Rate is 1.384036 and direct rate is 1.384036
Singapore Dollar: max Exchange Rate is 1.384036 and direct rate is 1.384036
Libyan Dinar: max Exchange Rate is 1.391679 and direct rate is 1.391679
Australian Dollar: max Exchange Rate is 1.399751 and direct rate is 1.399751
New Zealand Dollar: max Exchange Rate is 1.50011 and direct rate is 1.50011
Bulgarian Lev: max Exchange Rate is 1.689337 and direct rate is 1.689337
Israeli Shekel: max Exchange Rate is 3.4198299999999997 and direct rate is 3.41983
Qatari Riyal: max Exchange Rate is 3.64 and direct rate is 3.64
Emirati Dirham: max Exchange Rate is 3.6724999999999994 and direct rate is 3.6725
Saudi Arabian Riyal: max Exchange Rate is 3.75 and direct rate is 3.75
Polish Zloty: max Exchange Rate is 3.8191049999999995 and direct rate is 3.819105
Romanian New Leu: max Exchange Rate is 4.176897 and direct rate is 4.176897
Malaysian Ringgit: max Exchange Rate is 4.250933999999999 and direct rate is 4.250934
Brazilian Real: max Exchange Rate is 5.098128 and direct rate is 5.098128
Danish Krone: max Exchange Rate is 6.428257999999999 and direct rate is 6.428258
Croatian Kuna: max Exchange Rate is 6.498288 and direct rate is 6.498288
Trinidadian Dollar: max Exchange Rate is 6.761224999999998 and direct rate is 6.761225
Turkish Lira: max Exchange Rate is 6.849880999999999 and direct rate is 6.849881
Chinese Yuan Renminbi: max Exchange Rate is 7.000242999999999 and direct rate is 7.000243
Hong Kong Dollar: max Exchange Rate is 7.752141999999998 and direct rate is 7.752142
Swedish Krona: max Exchange Rate is 8.860053 and direct rate is 8.860053
Norwegian Krone: max Exchange Rate is 9.131606 and direct rate is 9.131606
Venezuelan Bolivar: max Exchange Rate is 9.987499999999997 and direct rate is 9.9875
Botswana Pula: max Exchange Rate is 11.541718999999999 and direct rate is 11.541719
South African Rand: max Exchange Rate is 16.458670999999995 and direct rate is 16.458671
Mexican Peso: max Exchange Rate is 22.265196 and direct rate is 22.265196
Czech Koruna: max Exchange Rate is 22.79715699999999 and direct rate is 22.797157
Taiwan New Dollar: max Exchange Rate is 29.406915999999992 and direct rate is 29.406916
Thai Baht: max Exchange Rate is 31.600252999999995 and direct rate is 31.600253
Mauritian Rupee: max Exchange Rate is 40.023896999999984 and direct rate is 40.023897
Philippine Peso: max Exchange Rate is 49.338157 and direct rate is 49.338157
Russian Ruble: max Exchange Rate is 71.11839699999997 and direct rate is 71.118397
Argentine Peso: max Exchange Rate is 71.77359799999999 and direct rate is 71.773598
Indian Rupee: max Exchange Rate is 74.57972499999995 and direct rate is 74.579725
Japanese Yen: max Exchange Rate is 107.19399399999993 and direct rate is 107.193994
Nepalese Rupee: max Exchange Rate is 119.88690899999999 and direct rate is 119.886909
Icelandic Krona: max Exchange Rate is 136.30829099999994 and direct rate is 136.308291
Pakistani Rupee: max Exchange Rate is 167.83629499999998 and direct rate is 167.836295
Sri Lankan Rupee: max Exchange Rate is 185.75839399999995 and direct rate is 185.758394
Hungarian Forint: max Exchange Rate is 300.7128289999999 and direct rate is 300.712829
Kazakhstani Tenge: max Exchange Rate is 413.23274799999984 and direct rate is 413.232748
Chilean Peso: max Exchange Rate is 769.0307209999994 and direct rate is 769.030721
South Korean Won: max Exchange Rate is 1196.2518299999992 and direct rate is 1196.25183
Colombian Peso: max Exchange Rate is 3625.2601279999963 and direct rate is 3625.260128
Indonesian Rupiah: max Exchange Rate is 14638.844749999982 and direct rate is 14638.84475
Iranian Rial: max Exchange Rate is 203429.99999999988 and direct rate is 203430.0
USD: max Exchange Rate is 1.0 and direct rate is 1.0

Process finished with exit code 0


	Source currency is Euro
Kuwaiti Dinar: max Exchange Rate is 0.3549689287727705 and direct rate is 0.34986423924438115
Bahraini Dinar: max Exchange Rate is 0.43448266172978356 and direct rate is 0.4320967078594971
Omani Rial: max Exchange Rate is 0.44451778215408344 and direct rate is 0.44435206550915146
British Pound: max Exchange Rate is 0.9089236862730836 and direct rate is 0.9055724731249191
Euro: max Exchange Rate is 1.0 and direct rate is 1.0
Swiss Franc: max Exchange Rate is 1.0749001023154772 and direct rate is 1.0592705128012352
Canadian Dollar: max Exchange Rate is 1.5491876544351681 and direct rate is 1.5268582866539009
Bruneian Dollar: max Exchange Rate is 1.5995774641218676 and direct rate is 1.5992960636440974
Singapore Dollar: max Exchange Rate is 1.5985097810735738 and direct rate is 1.5913355716294904
Libyan Dinar: max Exchange Rate is 1.6086546719511559 and direct rate is 1.6022535902709487
Australian Dollar: max Exchange Rate is 1.6164862579033483 and direct rate is 1.5944880640413293
New Zealand Dollar: max Exchange Rate is 1.7343901585022934 and direct rate is 1.7204160734635092
Bulgarian Lev: max Exchange Rate is 1.9526689990172101 and direct rate is 1.9456429089332103
Israeli Shekel: max Exchange Rate is 3.951000272322415 and direct rate is 3.94633111020479
Qatari Riyal: max Exchange Rate is 4.209345502054148 and direct rate is 4.209345502054148
Emirati Dirham: max Exchange Rate is 4.244666847186801 and direct rate is 4.224494558895594
Saudi Arabian Riyal: max Exchange Rate is 4.335948058654476 and direct rate is 4.3136163806810055
Polish Zloty: max Exchange Rate is 4.415727961180012 and direct rate is 4.378156016261313
Romanian New Leu: max Exchange Rate is 4.830053500893686 and direct rate is 4.8086427474907865
Malaysian Ringgit: max Exchange Rate is 4.911807188245628 and direct rate is 4.852321480004994
Brazilian Real: max Exchange Rate is 5.89133609798534 and direct rate is 5.835816326778043
Danish Krone: max Exchange Rate is 7.428369039378174 and direct rate is 7.317202397236667
Croatian Kuna: max Exchange Rate is 7.518402343893553 and direct rate is 7.518402343893553
Trinidadian Dollar: max Exchange Rate is 7.814142536673577 and direct rate is 7.70621674537905
Turkish Lira: max Exchange Rate is 7.9152763395593455 and direct rate is 7.915276339559348
Chinese Yuan Renminbi: max Exchange Rate is 8.084857769212821 and direct rate is 8.06814089170341
Hong Kong Dollar: max Exchange Rate is 8.964211060482718 and direct rate is 8.824964191875617
Swedish Krona: max Exchange Rate is 10.247892337476225 and direct rate is 10.214620558456964
Norwegian Krone: max Exchange Rate is 10.554913457910613 and direct rate is 10.363348442425096
Venezuelan Bolivar: max Exchange Rate is 11.540308385089922 and direct rate is 11.432601689225242
Botswana Pula: max Exchange Rate is 13.345529946442305 and direct rate is 13.212309237920605
South African Rand: max Exchange Rate is 19.01175882562972 and direct rate is 18.85152107718134
Mexican Peso: max Exchange Rate is 25.716425730155684 and direct rate is 25.31022739040592
Czech Koruna: max Exchange Rate is 26.340660559203577 and direct rate is 25.98533236110024
Taiwan New Dollar: max Exchange Rate is 34.01144003973537 and direct rate is 33.850470321004096
Thai Baht: max Exchange Rate is 36.5158149700251 and direct rate is 36.10252426502359
Mauritian Rupee: max Exchange Rate is 46.25326398955077 and direct rate is 46.25326398955078
Philippine Peso: max Exchange Rate is 57.10618827198232 and direct rate is 56.26650968331637
Russian Ruble: max Exchange Rate is 82.33033286275823 and direct rate is 82.33033286275823
Argentine Peso: max Exchange Rate is 83.02711112576311 and direct rate is 81.82880850088172
Indian Rupee: max Exchange Rate is 86.20704409798984 and direct rate is 85.06810178197233
Japanese Yen: max Exchange Rate is 123.99979886381384 and direct rate is 123.34058933330526
Nepalese Rupee: max Exchange Rate is 138.63231948897203 and direct rate is 136.46195055817728
Icelandic Krona: max Exchange Rate is 157.4108323891277 and direct rate is 155.36748514709748
Pakistani Rupee: max Exchange Rate is 193.8736293964924 and direct rate is 193.69769638234138
Sri Lankan Rupee: max Exchange Rate is 214.85878918524165 and direct rate is 213.43963422546128
Hungarian Forint: max Exchange Rate is 347.36022210093046 and direct rate is 343.66384272031064
Kazakhstani Tenge: max Exchange Rate is 477.20729499225143 and direct rate is 475.83229281553884
Chilean Peso: max Exchange Rate is 889.1897525289786 and direct rate is 886.6839358370023
South Korean Won: max Exchange Rate is 1383.1122589235615 and direct rate is 1368.9285679022516
Colombian Peso: max Exchange Rate is 4194.589184002575 and direct rate is 4194.589184002581
Indonesian Rupiah: max Exchange Rate is 16933.03059456624 and direct rate is 16782.135524062352
Iranian Rial: max Exchange Rate is 235318.87231442062 and direct rate is 233380.39471322397
USD: max Exchange Rate is 1.1548148042522797 and direct rate is 1.1289337760823115

Process finished with exit code 0

	Source currency is British Pound
Kuwaiti Dinar: max Exchange Rate is 0.38994902045989793 and direct rate is 0.3868888293651884
Bahraini Dinar: max Exchange Rate is 0.4774223057673119 and direct rate is 0.4726751721391758
Omani Rial: max Exchange Rate is 0.4889197197961762 and direct rate is 0.4817128231818938
British Pound: max Exchange Rate is 1.0 and direct rate is 1.0
Euro: max Exchange Rate is 1.0972507615196385 and direct rate is 1.0884539925130332
Swiss Franc: max Exchange Rate is 1.180855807130814 and direct rate is 1.1752646778405815
Canadian Dollar: max Exchange Rate is 1.7041924239766433 and direct rate is 1.7041924239766433
Bruneian Dollar: max Exchange Rate is 1.758417927372908 and direct rate is 1.7418294619424863
Singapore Dollar: max Exchange Rate is 1.75858265187143 and direct rate is 1.7371907626281005
Libyan Dinar: max Exchange Rate is 1.7698456935886695 and direct rate is 1.7698456935886695
Australian Dollar: max Exchange Rate is 1.7782485207994012 and direct rate is 1.7498437417311214
New Zealand Dollar: max Exchange Rate is 1.905750639416302 and direct rate is 1.8764421937575608
Bulgarian Lev: max Exchange Rate is 2.1477169602255564 and direct rate is 2.14118987684579
Israeli Shekel: max Exchange Rate is 4.344423340143838 and direct rate is 4.3073620192144695
Qatari Riyal: max Exchange Rate is 4.623865611753706 and direct rate is 4.610305700004172
Emirati Dirham: max Exchange Rate is 4.667021889685482 and direct rate is 4.593056875198144
Saudi Arabian Riyal: max Exchange Rate is 4.763093711057137 and direct rate is 4.697669675479464
Polish Zloty: max Exchange Rate is 4.851560761925369 and direct rate is 4.770988190923106
Romanian New Leu: max Exchange Rate is 5.3125172919154675 and direct rate is 5.236835739345128
Malaysian Ringgit: max Exchange Rate is 5.4032164702813406 and direct rate is 5.388985817091683
Brazilian Real: max Exchange Rate is 6.469861685528605 and direct rate is 6.450941689419211
Danish Krone: max Exchange Rate is 8.163413541580963 and direct rate is 8.158089136182852
Croatian Kuna: max Exchange Rate is 8.256557106921921 and direct rate is 8.199227153086992
Trinidadian Dollar: max Exchange Rate is 8.587603546401816 and direct rate is 8.431941350765518
Turkish Lira: max Exchange Rate is 8.699345986889936 and direct rate is 8.658882685348955
Chinese Yuan Renminbi: max Exchange Rate is 8.894979734067297 and direct rate is 8.754205843096814
Hong Kong Dollar: max Exchange Rate is 9.862446315200819 and direct rate is 9.86244631520082
Swedish Krona: max Exchange Rate is 11.258053796341077 and direct rate is 11.05963916183281
Norwegian Krone: max Exchange Rate is 11.611869954664709 and direct rate is 11.611869954664712
Venezuelan Bolivar: max Exchange Rate is 12.696674714694 and direct rate is 12.551924850737192
Botswana Pula: max Exchange Rate is 14.656356592520146 and direct rate is 14.543437199983478
South African Rand: max Exchange Rate is 20.916782247786742 and direct rate is 20.713293367261432
Mexican Peso: max Exchange Rate is 28.255878116291036 and direct rate is 27.859107590440534
Czech Koruna: max Exchange Rate is 28.927297252958354 and direct rate is 28.8714763049169
Taiwan New Dollar: max Exchange Rate is 37.38615236136526 and direct rate is 36.83416720396938
Thai Baht: max Exchange Rate is 40.13012442249261 and direct rate is 39.73406058631912
Mauritian Rupee: max Exchange Rate is 50.807608840837354 and direct rate is 50.76725043984345
Philippine Peso: max Exchange Rate is 62.71398089710562 and direct rate is 62.549933468511576
Russian Ruble: max Exchange Rate is 90.41512099907725 and direct rate is 89.38570586015355
Argentine Peso: max Exchange Rate is 91.22883079669697 and direct rate is 90.09075377081402
Indian Rupee: max Exchange Rate is 94.81808273360797 and direct rate is 93.19909100644563
Japanese Yen: max Exchange Rate is 136.17650297639477 and direct rate is 134.7965694352844
Nepalese Rupee: max Exchange Rate is 152.38781458735616 and direct rate is 152.33051358688812
Icelandic Krona: max Exchange Rate is 173.12143058048665 and direct rate is 172.40581198847715
Pakistani Rupee: max Exchange Rate is 213.15694603088593 and direct rate is 209.85816701890167
Sri Lankan Rupee: max Exchange Rate is 236.0833209537186 and direct rate is 235.68893547325473
Hungarian Forint: max Exchange Rate is 381.67715697223343 and direct rate is 379.18053686070124
Kazakhstani Tenge: max Exchange Rate is 524.4861144361386 and direct rate is 515.6828363003191
Chilean Peso: max Exchange Rate is 977.4876408011907 and direct rate is 968.1023595824726
South Korean Won: max Exchange Rate is 1521.2684064125062 and direct rate is 1519.017544340763
Colombian Peso: max Exchange Rate is 4610.788315438679 and direct rate is 4546.226694026359
Indonesian Rupiah: max Exchange Rate is 18595.84380207608 and direct rate is 18449.11218712946
Iranian Rial: max Exchange Rate is 258544.86904489537 and direct rate is 255117.65687975948
USD: max Exchange Rate is 1.2687951433728477 and direct rate is 1.2675809283876338

Process finished with exit code 0
